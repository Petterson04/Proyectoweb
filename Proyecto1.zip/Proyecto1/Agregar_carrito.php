<?php
//Seguridad de sesssiones para esta pestaña
session_start();
error_reporting(0); 
$varsesion=$_SESSION['correo'];
if($varsesion== null|| $varsesion== ''){
    header('location: login.html');
    die();
}
?>
<?php 
if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST['Id_Producto'])&& isset($_POST['boton_id'])){
    $Id_Producto=$_POST['Id_Producto'];
    $boton_id=$_POST['boton_id'];
}
//realizamos la consulta con la base de datos para obtener la informacion del producto
include('base.php');
$sql=mysqli_query($conect,"SELECT*FROM productos WHERE Id_Producto='$Id_Producto'");
$producto=mysqli_fetch_array($sql);
//verificamos si el carro ya existe 
if(!isset($_SESSION['carrito'])) {
    $_SESSION['carrito']=array(); 
}
//verificamos si el producto ya se encuentra en el carro
if(isset($_SESSION['carrito'][$boton_id])) {
    $_SESSION['carrito'][$boton_id]['cantidad']++;
    $_SESSION['carrito'][$boton_id]['subtotal']==$_SESSION['carrito'][$boton_id]['Precio']*$_SESSION['carrito']['boton_id']['cantidad'];
}else{
    $producto_carrito=array(
        'id_prducto'=>$producto['Id_Producto'],
        'NombreProducto'=> $producto['NombreProducto'],
        'Onzas'=> $producto['Onzas'],
        'Precio'=> $producto['Precio'],
        'cantidad'=>1,
        'subtotal'=> $producto['Precio'],
    );
    $_SESSION['carrito'][$boton_id]=$producto_carrito;
}
echo"<pre>";
print_r($_SESSION['carrito']);
echo"</pre>";
header("Location: productos.php");
?>